const http = require('http');
const hostname = "127.0.0.1";
const port = 8080;

const server = http.createServer((req, res) => {
    res.setHeader('Content-Type', 'text/plain');
    res.statusCode = 200;
    res.end("Junior Frontend Vizsga");

});

server.listen(port, hostname, () => {
    console.log(`A vizsga szerver a http://${hostname}:${port}/ címen elérhető`);
});
