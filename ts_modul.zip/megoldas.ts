/*A megoldásodat ebben a fájlban készítsd el, majd fordítsd le typeScript compiler segítségével*/
//1. feladat
//function KivalasztottBetuk(viszgaltSzoveg: string, kivalasztottBetuk: number[]): number {}


//2. feladat
function Szamtani(elsoErtek: number, masodikErtek: number, harmadikErtek: number): boolean {
    if (masodikErtek - elsoErtek == harmadikErtek - masodikErtek) {

        return true;
    }
    else {
        return false;

    }
}


//3. feladat
function Vizsgajegy(osszPont: number): string {
    var pontszam: number = 0;
    for (let i: number = 0; i < osszPont; i++) {
        pontszam += osszPont[i];
    }

    if (pontszam <= 49) {
        return "Elégtelen";
    }
    else if (pontszam <= 59) {
        return "Elégséges";
    }
    else if (pontszam <= 69) {
        return "Közepes";
    }
    else if (pontszam <= 79) {
        return "Jó";
    }
    else
        return "Jeles";
}