//Ide illessze be a JavasScript kódot a teszteléshez
//1. feladat
function OsztokSzama(vizsgaltSzam){
    let osztok=[];
    for (let i=0;vizsgaltSzam.length;i++){
        if (vizsgaltSzam[i]%i==0){
            osztok.push(ujTomb[i]);
        }
    }

}

function OszthatoSzamok(oszto, vizsgaltTomb) {
    var oszthatokMennyisege = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % oszto == 0) {
            oszthatokMennyisege++;
        }
    }
    return oszthatokMennyisege;
}

//2. feladat
function ParatlanLista(vizsgaltTomb){
	let eredmenyek=[];
	for(let i=0;i<vizsgaltTomb.length;i++){
		if(vizsgaltTomb[i]%2!=0){
    		eredmenyek.push(vizsgaltTomb[i]);
    	}
	}
    return eredmenyek;
}

//3. feladat
function VizsgaEredmeny(nev){

}

