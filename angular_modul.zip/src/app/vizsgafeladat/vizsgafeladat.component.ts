import { Component } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrls: ['./vizsgafeladat.component.css']
})
export class VizsgafeladatComponent {
  htmlModul!: number;
  bootstrapModul!: number;
  javaScriptModul!: number;
  typeScriptModul!: number;
  angularModul!: number;

ModulOsszegek():number {
    return this.htmlModul + this.bootstrapModul + this.javaScriptModul + this.typeScriptModul + this.angularModul + this.serverModul;
    
  }

  eredmenyek: string[] = [];
  mezokOsszege(): any {
    for (let i = 1; i <= this.ModulOsszegek; i++) {
      if (this.ModulOsszegek < 50)
        return 'Sikertelen vizsga, szerzett pont: ';
      else if (this.ModulOsszegek > 60)
        return 'Sikeres vizsga: (2-es);';
        else if (this.ModulOsszegek > 27)
        return '0. szint';
        else {
          return 'Hiba a kitöltés során';
        }
    }
   
        }
    }

  }

 EredmenyMentes(): void {
    this.eredmenyek.push(`${this.ModulOsszegek}`);

  }

}
