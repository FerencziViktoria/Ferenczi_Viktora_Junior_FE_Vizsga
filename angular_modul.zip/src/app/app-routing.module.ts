import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
  [path: "vizsgafeladat", component: VizsgafeladatComponent],
  [path: "", redirectTo: "vizsgafeladat", pathMatch: "full"],
  [path: "**", component: VizsgafeladatComponent]
}
